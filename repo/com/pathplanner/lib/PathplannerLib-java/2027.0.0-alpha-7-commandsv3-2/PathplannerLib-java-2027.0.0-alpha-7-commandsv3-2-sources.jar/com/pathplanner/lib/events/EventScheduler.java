package com.pathplanner.lib.events;

import com.pathplanner.lib.auto.CommandSpec;
import com.pathplanner.lib.auto.CommandUtil;
import com.pathplanner.lib.path.EventMarker;
import com.pathplanner.lib.path.PathPlannerPath;
import com.pathplanner.lib.trajectory.PathPlannerTrajectory;
import java.io.IOException;
import java.util.*;
import org.json.simple.parser.ParseException;
import org.wpilib.command2.Command;
import org.wpilib.command2.CommandScheduler;
import org.wpilib.command2.Commands;
import org.wpilib.command2.Subsystem;
import org.wpilib.driverstation.DriverStationErrors;
import org.wpilib.event.EventLoop;

/**
 * Scheduler for running events while following a trajectory, using Commands v2
 *
 * <p>Note: The command that is running this scheduler must have the requirements of all commands
 * that will be run during the path being followed.
 */
public class EventScheduler extends EventSchedulerBase {

  private static final EventLoop eventLoop = new EventLoop();

  private final Map<Command, Boolean> eventCommands;

  private final Map<CommandSpec, Command> builtCommands;

  private final Queue<Event> upcomingEvents;

  /** Create a new EventScheduler */
  public EventScheduler() {
    this.eventCommands = new HashMap<>();
    this.builtCommands = new IdentityHashMap<>();
    this.upcomingEvents =
        new PriorityQueue<>(Comparator.comparingDouble(Event::getTimestampSeconds));
  }

  /**
   * Initialize the EventScheduler for the given trajectory. This should be called from the
   * initialize method of the command running this scheduler.
   *
   * @param trajectory The trajectory this scheduler should handle events for
   */
  public void initialize(PathPlannerTrajectory trajectory) {
    eventCommands.clear();
    upcomingEvents.clear();
    upcomingEvents.addAll(trajectory.getEvents());
  }

  /**
   * Run the scheduler. This should be called from the execute method of the command running this
   * scheduler.
   *
   * @param time The current time along the trajectory
   */
  public void execute(double time) {
    // Check for events that should be handled this loop
    while (!upcomingEvents.isEmpty() && time >= upcomingEvents.peek().getTimestampSeconds()) {
      upcomingEvents.poll().handleEvent(this);
    }
    // Run currently running commands
    for (var entry : eventCommands.entrySet()) {
      if (!entry.getValue()) {
        continue;
      }
      entry.getKey().execute();
      if (entry.getKey().isFinished()) {
        entry.getKey().end(false);
        eventCommands.put(entry.getKey(), false);
      }
    }
    eventLoop.poll();
  }

  /**
   * End commands currently/events currently being handled by this scheduler. This should be called
   * from the end method of the command running this scheduler.
   */
  public void end() {
    // Cancel all currently running commands
    for (var entry : eventCommands.entrySet()) {
      if (!entry.getValue()) {
        continue;
      }
      entry.getKey().end(true);
    }
    // Cancel any unhandled events
    for (Event e : upcomingEvents) {
      e.cancelEvent(this);
    }
    eventCommands.clear();
    upcomingEvents.clear();
  }

  /**
   * Build the commands for the event markers of a path ahead of time, so they do not need to be
   * built while the path is being followed.
   *
   * @param path The path to build event commands for
   * @return Set of subsystems required by the event commands
   */
  public Set<Subsystem> buildEventCommands(PathPlannerPath path) {
    Set<Subsystem> allReqs = new HashSet<>();
    for (EventMarker m : path.getEventMarkers()) {
      if (m.command() != null) {
        allReqs.addAll(getEventCommand(m.command()).getRequirements());
      }
    }
    return allReqs;
  }

  /**
   * Get the event requirements for the given path
   *
   * @param path The path to get all requirements for
   * @return Set of event requirements for the given path
   */
  public static Set<Subsystem> getSchedulerRequirements(PathPlannerPath path) {
    return new EventScheduler().buildEventCommands(path);
  }

  /**
   * Get the event loop used to poll global event triggers
   *
   * @return Event loop that polls global event triggers
   */
  protected static EventLoop getEventLoop() {
    return eventLoop;
  }

  @Override
  protected void scheduleCommand(CommandSpec command) {
    scheduleCommand(getEventCommand(command));
  }

  @Override
  protected void cancelCommand(CommandSpec command) {
    Command built = builtCommands.get(command);
    if (built != null) {
      cancelCommand(built);
    }
  }

  @Override
  @SuppressWarnings("resource") // The command scheduler is a singleton that must not be closed
  protected void handleOneShotTrigger(String eventName) {
    EventConditions.setEventActive(eventName, true);

    // We schedule this command with the main command scheduler so that it is guaranteed to be run
    // in its entirety, since the EventScheduler could cancel this command before it finishes
    CommandScheduler.getInstance()
        .schedule(
            Commands.waitSeconds(0.0)
                .andThen(Commands.runOnce(() -> EventConditions.setEventActive(eventName, false)))
                .ignoringDisable(true));
  }

  private Command getEventCommand(CommandSpec spec) {
    return builtCommands.computeIfAbsent(spec, EventScheduler::buildEventCommand);
  }

  private static Command buildEventCommand(CommandSpec spec) {
    try {
      return CommandUtil.buildCommand(spec, false);
    } catch (IOException | ParseException e) {
      DriverStationErrors.reportError(
          "Failed to build event command: " + e.getMessage(), e.getStackTrace());
      return Commands.none();
    }
  }

  /**
   * Schedule a command on this scheduler. This will cancel other commands that share requirements
   * with the given command.
   *
   * @param command The command to schedule
   */
  protected void scheduleCommand(Command command) {
    // Check for commands that should be cancelled by this command
    for (var entry : eventCommands.entrySet()) {
      if (!entry.getValue()) {
        continue;
      }
      if (!Collections.disjoint(entry.getKey().getRequirements(), command.getRequirements())) {
        cancelCommand(entry.getKey());
      }
    }
    command.initialize();
    eventCommands.put(command, true);
  }

  /**
   * Cancel a command on this scheduler.
   *
   * @param command The command to cancel
   */
  protected void cancelCommand(Command command) {
    if (!eventCommands.containsKey(command) || !eventCommands.get(command)) {
      // Command is not currently running
      return;
    }
    command.end(true);
    eventCommands.put(command, false);
  }
}
